import { Component, OnInit } from '@angular/core';

import { ROUTE_ANIMATIONS_ELEMENTS } from '@app/core';

@Component({
  selector: 'anms-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {
  routeAnimationsElements = ROUTE_ANIMATIONS_ELEMENTS;
  releaseButler = require('../../../assets/release-butler.png');
  imgSrc: string;
  counter: number = 45;

  constructor() {}

  changeImageSource() {
    this.imgSrc = 'https://source.unsplash.com/random/800x600';
  }
  ngOnInit() {
    this.imgSrc = 'https://source.unsplash.com/random/800x600';
  }
}
