export * from './static-routing.module';
export * from './static.module';
export * from './about/about.component';
